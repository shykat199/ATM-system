package ATM;

import java.io.*;

public class Atm extends OptionMenu {
    public static void main(String[] args) throws IOException {
        OptionMenu optionMenu = new OptionMenu();
        optionMenu.getLogin();
    }
}
